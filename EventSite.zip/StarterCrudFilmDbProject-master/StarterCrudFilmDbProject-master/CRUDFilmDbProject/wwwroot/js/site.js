﻿var i = 0;
var images = [];
var time = 3000;

images[0] = "images/Banner1.jpg";
images[1] = "images/Banner2.jpg";
images[2] = "images/Banner3.jpg";
images[3] = "images/Banner4.jpg";



function changeBannerImage()
{
    document.myBanner.src = images[i];

    if (i < images.length - 1) {
        i++
    }
    else {
        i = 0;
    }

    setTimeout("changeBannerImage()", time);
}
changeBannerImage();

